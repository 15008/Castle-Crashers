from flask_wtf import FlaskForm
from wtforms import IntegerField, TextField, TextAreaField, SelectField, SubmitField, BooleanField
from wtforms.validators import DataRequired, Optional, ValidationError, InputRequired, NumberRange, Length
from app.models import Orb, Location, Weapon
from datetime import datetime

#==============================Editing Locations==============================#
class Edit_Location(FlaskForm):
    #Name, required, must be a suitable length (-1 to prevent 'empty' error occuring)
    name = TextField('Name', validators=[
        InputRequired(message=('Name?')),
        Length(min=-1, max=50, message='That\'s too long for a name!')])
    #Description, required, less than 2000 characters
    description = TextAreaField('Desciption', validators=[
        InputRequired(message=('Elaborate please...')),
        Length(min=-1, max=2000, message='Must be less than 2000 characters!')])
    #Chapter, required, must be a suitable number
    chapter = IntegerField('Chapter', validators=[
        InputRequired(message=('Please enter a number!')),
        NumberRange(min=0, max=999, message='Be realistic! ... 0-999 is a suitable range')])
    #Location Type, required, choices (value, name)
    localeType = SelectField('Location Type',
        validators=[InputRequired(message=('How could an error come up?!'))],
        choices = [('Normal', 'Normal'), ('Boss', 'Boss'), ('Special', 'Special'), ('Storage', 'Storage'), ('Store', 'Store'), ('Arena', 'Arena')])
    #Setup add variable as True/False input
    add = BooleanField()
    #id Pivitol Value for validator
    id = IntegerField()
    #Custom Name Validator
    def validate_name(form, name):
        #Test whether there is an entry with the entered name
        test = Location.query.filter_by(name = name.data).first()
        #If there is an existing entry
        if test is not None:
            if form.add.data == True:
                raise ValidationError('That Location already exists!')
            #If editing then...
            else:
                #Use the id a pivotol value and map the current entry
                current = Location.query.get(form.id.data)
                #If the existing name is same as the one entered (or left untouched), don't raise an error
                if test.name != current.name:
                    raise ValidationError('That Location already exists!')

#==============================Editing Weapons==============================#
class Edit_Weapon(FlaskForm):
    #Name, required, must be a suitable length
    name = TextField('Name', validators=[
        DataRequired(),
        Length(min=-1, max=50, message='That\'s too long for a name!')])
    #Required Items, required, must be less than 2000 characters
    reqItem = TextAreaField('Required Items', validators=[
        InputRequired(message=('Requirements?')),
        Length(min=-1, max=2000, message='Description is limited to 2000 characters')])
    #Level requirement, required, must be a suitable number
    reqLevel = IntegerField('Required Level', validators=[
        InputRequired(message=('Level requirement?')),
        NumberRange(min=0, max=99, message='Level requirement must be between 0-99!')])
    #Gamemode, required, choices (value, names)
    mode = SelectField('Mode',
        validators = [InputRequired( message = ('How could an error come up?!'))],
        choices = [('Normal', 'Normal'), ('Both', 'Both'), ('Insane', 'Insane')])
    #Strength, required, must be a suitable number
    strength = IntegerField('Strength', validators=[
        InputRequired(message=('Value?')),
        NumberRange(min=-10, max=10, message='Strength Bonus must be between -10 and 10')])
    #Magic, required, must be a suitable number
    magic = IntegerField('Magic', validators=[
        InputRequired(message=('Value?')),
        NumberRange(min=-10, max=10, message='Magic Bonus must be between -10 and 10')])
    #Defense, required, must be a suitable number
    defense = IntegerField('Defense', validators=[
        InputRequired(message=('Value?')),
        NumberRange(min=-10, max=10, message='Defense Bonus must be between -10 and 10')])
    #Agility, required, must be a suitable number
    agility = IntegerField('Agility', validators=[
        InputRequired(message=('Value?')),
        NumberRange(min=-10, max=10, message='Agility Bonus must be between -10 and 10')])
    #Ice Special, required, must be a suitable percentage
    iceSpecial = IntegerField('Ice', validators=[
        InputRequired(message=('Value?')),
        NumberRange(min=-10, max=10, message='Ice Special Bonus must be between -10 and 10')])
    #Critical Damage Special, required, must be a suitable percentage
    critSpecial = IntegerField('Critical Damage', validators=[
        InputRequired(message=('Value?')),
        NumberRange(min=-10, max=10, message='Critical Special Bonus must be between -10 and 10')])
    #Fire Special, required, must be a suitable percentage
    fireSpecial = IntegerField('Fire', validators=[
        InputRequired(message=('Value?')),
        NumberRange(min=-10, max=10, message='Fire Special Bonus must be between -10 and 10')])
    #Electricity Special, required, must be a suitable percentage
    elecSpecial = IntegerField('Electricity', validators=[
        InputRequired(message=('Value?')),
        NumberRange(min=-10, max=10, message='Electricity Special Bonus must be between -10 and 10')])
    #Poison Special, required, must be a suitable percentage
    poiSpecial = IntegerField('Poison', validators=[
        InputRequired(message=('Value?')),
        NumberRange(min=-10, max=10, message='Poison Special Bonus must be between -10 and 10')])
    #Cost, required, must be a suitable value
    cost = IntegerField('Cost', validators=[
        InputRequired(message=('Cost?')),
        NumberRange(min=0, max=10000, message='Cost must range between 0 and 10000 GOLD')])
    #Location id, required, choices are dynamic, value type is id
    locationid = SelectField('Location', validators=[InputRequired(message=('Value?'))], coerce=int)
    #Setup add variable as True/False input
    add = BooleanField()
    #id Pivitol Value for validator
    id = IntegerField()
    #Custom Name Validator
    def validate_name(form, name):
        #Test whether there is an entry with the entered name
        test = Weapon.query.filter_by(name = name.data).first()
        #If there is an existing entry
        if test is not None:
            if form.add.data == True:
                raise ValidationError('That Weapon already exists!')
            #If editing then...
            else:
                #Use the id a pivotol value and map the current entry
                current = Weapon.query.get(form.id.data)
                #If the existing name is same as the one entered (or left untouched), don't raise an error
                if test.name != current.name:
                    raise ValidationError('That Weapon already exists!')

#==============================Editing Animal Orbs==============================#

class Edit_Orb(FlaskForm):
    #Name, required, must be a suitable length
    name = TextField('Name', validators=[
        InputRequired(message=('Name?')),
        Length(min=-1, max=50, message='That\'s too long for a name!')])
    #Description, required, length requirement
    description = TextAreaField('Description', validators=[
        InputRequired(message=('Elaborate please...')),
        Length(min=-1, max=2000, message='Description is limited to 2000 characters')])
    #Cost, required, must be a suitable value
    cost = IntegerField('Cost', validators=[
        InputRequired(message=('Cost?')),
        NumberRange(min=0, max=10000, message='Cost must range between 0 and 10000 GOLD')])
    #Requirements, required, length requirement
    req = TextAreaField('Requirements', validators=[
        InputRequired(message=('What\'s needed?')),
        Length(min=-1, max=1000, message='Requirements is limited to 1000 characters')])
    #Magic Bonus, required, must be a suitable number
    magicBonus = IntegerField('Magic', validators=[
        InputRequired(message=('Value?')),
        NumberRange(min=-10, max=10, message='Magic Bonus must be between -10 and 10')])
    #Strength Bonus, required, must be a suitable number
    strengthBonus = IntegerField('Strength', validators=[
        InputRequired(message=('Value?')),
        NumberRange(min=-10, max=10, message='Strength Bonus must be between -10 and 10')])
    #Defense Bonus, required, must be a suitable number
    defenseBonus = IntegerField('Defense', validators=[
        InputRequired(message=('Value?')),
        NumberRange(min=-10, max=10, message='Defense Bonus must be between -10 and 10')])
    #Agility Bonus, required, must be a suitable number
    agilityBonus = IntegerField('Agility', validators=[
        InputRequired(message=('Value?')),
        NumberRange(min=-10, max=10, message='Agility Bonus must be between -10 and 10')])
    #Experience Bonus, required, must be a suitable percentage
    xpBonus = IntegerField('XP', validators=[
        InputRequired(message=('Make sure the value is simply an integer')),
        NumberRange(min=0, max=100, message='It\'s a percentage! (0-100)')])
    #Location id, required, choices are dynamic, value type is id
    locationid = SelectField('Location', validators=[InputRequired(message=('Value?'))], coerce=int)
    #Setup add variable as True/False input
    add = BooleanField()
    #id Pivitol Value for validator
    id = IntegerField()
    #Custom Name Validator
    def validate_name(form, name):
        #Test whether there is an entry with the entered name
        test = Orb.query.filter_by(name = name.data).first()
        #If there is an existing entry
        if test is not None:
            if form.add.data == True:
                raise ValidationError('That Animal Orb already exists!')
            #If editing then...
            else:
                #Use the id a pivotol value and map the current entry
                current = Orb.query.get(form.id.data)
                #If the existing name is same as the one entered (or left untouched), don't raise an error
                if test.name != current.name:
                    raise ValidationError('That Animal Orb already exists!')
