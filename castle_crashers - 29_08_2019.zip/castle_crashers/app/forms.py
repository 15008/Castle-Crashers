from flask_wtf import FlaskForm
from wtforms import IntegerField, TextField, TextAreaField, SelectField, SubmitField
from wtforms.ext.sqlalchemy.fields import QuerySelectField
from wtforms.validators import DataRequired, Optional, ValidationError
from app.models import Orb, Location, Weapon
from datetime import datetime

#==========Editing Locations==========#

class Edit_Location(FlaskForm):
    name = TextField('Name', validators=[DataRequired(message=('Name?'))])
    description = TextAreaField('Desciption', validators=[DataRequired(message=('Elaborate please...'))])
    chapter = IntegerField('Chapter', validators=[DataRequired(message=('Please enter a chapter number!'))])
    localeType = SelectField('Location Type',
        validators=[DataRequired(message=('How could an error come up?!'))],
        choices = [('Normal', 'Normal'), ('Boss', 'Boss'), ('Special', 'Special'), ('Storage', 'Storage'), ('Store', 'Store'), ('Arena', 'Arena')])

#    def validate_name(self, name):
#        location = Location.query.filter_by(name = name.data).first()
#        if location is not None:
#            raise ValidationError('Please don\'t duplicate locations')

#==========Editing Weapons==========#

class Edit_Weapon(FlaskForm):
    name = TextField('Name', validators=[DataRequired(message=('Name?'))])
    reqItem = TextAreaField('Required Items', validators=[DataRequired(message=('Requirements?'))])
    reqLevel = IntegerField('Required Level', validators=[DataRequired(message=('Level requirement?'))])
    mode = SelectField('Mode',
        validators = [DataRequired( message = ('How could an error come up?!') )],
        choices = [('Normal', 'Normal'), ('Both', 'Both'), ('Insane', 'Insane')])
    strength = IntegerField('Strength')
    magic = IntegerField('Magic')
    defense = IntegerField('Defense')
    agility = IntegerField('Agility')
    iceSpecial = IntegerField('Ice')
    critSpecial = IntegerField('Critical Damage')
    fireSpecial = IntegerField('Fire')
    elecSpecial = IntegerField('Electricity')
    poiSpecial = IntegerField('Poison')
    cost = IntegerField('Cost')

    locationid = QuerySelectField('Location',
        validators=[DataRequired()],
        query_factory = lambda:Location.query.all(),
        get_label = 'name')

    def validate_name(self, name):
        if add == True:
            weapon = Weapon.query.filter_by(name = name.data).first()
            if weapon is not None:
                raise ValidationError('Please don\'t duplicate weapons')

#==========Editing Animal Orbs==========#

class Edit_Orb(FlaskForm):
    name = TextField('Name', validators=[DataRequired(message=('Name?'))])
    description = TextAreaField('Description', validators=[DataRequired(message=('Elaborate please...'))])
    cost = IntegerField('Cost')
    req = TextAreaField('Requirements', validators=[DataRequired(message=('What\'s needed?'))])
    magicBonus = IntegerField('Magic')
    strengthBonus = IntegerField('Strength')
    defenseBonus = IntegerField('Defense')
    agilityBonus = IntegerField('Agility')
    xpBonus = IntegerField('XP')

    locationid = QuerySelectField('Location',
        validators=[DataRequired()],
        query_factory = lambda:Location.query.all(),
        get_label = 'name')

#    def validate_name(self, name):
#        orb = Orb.query.filter_by(name = name.data).first()
#        if orb is not None:
#            raise ValidationError('Please don\'t duplicate Animal Orbs')
