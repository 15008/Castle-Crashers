from flask_wtf import FlaskForm
from wtforms import IntegerField, TextField, TextAreaField, SelectField, SubmitField, BooleanField
from wtforms.ext.sqlalchemy.fields import QuerySelectField
from wtforms.validators import DataRequired, Optional, ValidationError, InputRequired
from app.models import Orb, Location, Weapon
from datetime import datetime

#==============================Editing Locations==============================#
class Edit_Location(FlaskForm):
    #Input required makes the form test whether the input from the user fits the field type displaying an error message
    name = TextField('Name', validators=[InputRequired(message=('Name?'))])
    description = TextAreaField('Desciption', validators=[InputRequired(message=('Elaborate please...'))])
    chapter = IntegerField('Chapter', validators=[InputRequired(message=('Please enter a number!'))])
    localeType = SelectField('Location Type',
        validators=[InputRequired(message=('How could an error come up?!'))],
        #(Value, Label)
        choices = [('Normal', 'Normal'), ('Boss', 'Boss'), ('Special', 'Special'), ('Storage', 'Storage'), ('Store', 'Store'), ('Arena', 'Arena')])
    #Setup add variable as True/False input
    add = BooleanField()
    #Make sure there is no two items with the same name, editing an existing item bypasses this
    def validate_name(form, name):
        if form.add.data == True:
            location = Location.query.filter_by(name = name.data).first()
            if location is not None:
                raise ValidationError('Please don\'t duplicate Locations')

#==============================Editing Weapons==============================#
class Edit_Weapon(FlaskForm):
    name = TextField('Name', validators=[InputRequired(message=('Name?'))])
    reqItem = TextAreaField('Required Items', validators=[InputRequired(message=('Requirements?'))])
    reqLevel = IntegerField('Required Level', validators=[InputRequired(message=('Level requirement?'))])
    mode = SelectField('Mode',
        validators = [InputRequired( message = ('How could an error come up?!'))],
        choices = [('Normal', 'Normal'), ('Both', 'Both'), ('Insane', 'Insane')])
    strength = IntegerField('Strength')
    magic = IntegerField('Magic')
    defense = IntegerField('Defense')
    agility = IntegerField('Agility')
    iceSpecial = IntegerField('Ice')
    critSpecial = IntegerField('Critical Damage')
    fireSpecial = IntegerField('Fire')
    elecSpecial = IntegerField('Electricity')
    poiSpecial = IntegerField('Poison')
    cost = IntegerField('Cost')
    locationid = QuerySelectField('Location',
        validators=[InputRequired()],
        #Set options to all possible locations (id, name)
        query_factory = lambda:Location.query.all(),
        get_label = 'name')
    #Setup add variable as True/False input
    add = BooleanField()
    #Make sure there is no two items with the same name, editing an existing item bypasses this
    def validate_name(form, name):
        if form.add.data == True:
            weapon = Weapon.query.filter_by(name = name.data).first()
            if weapon is not None:
                raise ValidationError('Please don\'t duplicate Weapons')

#==============================Editing Animal Orbs==============================#

class Edit_Orb(FlaskForm):
    name = TextField('Name', validators=[InputRequired(message=('Name?'))])
    description = TextAreaField('Description', validators=[InputRequired(message=('Elaborate please...'))])
    cost = IntegerField('Cost')
    req = TextAreaField('Requirements', validators=[InputRequired(message=('What\'s needed?'))])
    magicBonus = IntegerField('Magic')
    strengthBonus = IntegerField('Strength')
    defenseBonus = IntegerField('Defense')
    agilityBonus = IntegerField('Agility')
    xpBonus = IntegerField('XP')
    locationid = QuerySelectField('Location',
        validators=[InputRequired()],
        query_factory = lambda:Location.query.all(),
        get_label = 'name')
    #Setup add variable as True/False input
    add = BooleanField()
    #Make sure there is no two items with the same name, editing an existing item bypasses this
    def validate_name(form, name):
        if form.add.data == True:
            orb = Orb.query.filter_by(name = name.data).first()
            if orb is not None:
                raise ValidationError('Please don\'t duplicate Animal Orbs')
