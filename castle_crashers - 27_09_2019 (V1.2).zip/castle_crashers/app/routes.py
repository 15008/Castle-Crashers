from flask import render_template, redirect, url_for, request, flash
from app import app, db
from app.models import Orb, Location, Weapon
from app.forms import Edit_Location, Edit_Orb, Edit_Weapon
from werkzeug.exceptions import HTTPException

#==============================Main Pages==============================#

#Home
@app.route('/')
def home():
    return render_template('home.html', page_title="Home")

#Contact
@app.route('/contact')
def contact():
    return render_template('contact.html', page_title="Contact")

#==============================Animal Orb Pages==============================#

#All Animal Orbs Page, order A-Z
@app.route('/all_orbs')
def all_orbs():
	orbs = Orb.query.order_by(Orb.name).all()
    #Pass Orbs to the template
	return render_template('all_orbs.html',page_title="Animal Orbs", orbs=orbs)

#Animal Orb Details Page
@app.route('/orb/<id>')
def orb_details(id):
    orb = Orb.query.filter_by(id = id).first()
    #Find location in which the Animal Orb is from
    location = Location.query.filter_by(id = orb.locationid).first()
    return render_template('orb_details.html', page_title=orb.name, orb=orb, location=location)

#Remove Animal Orb
@app.route('/remove_orb/<id>')
def remove_orb(id):
    #Select the Orb and Delete
    Orb.query.filter_by(id = id).delete()
    #Save Changes
    db.session.commit()
    #Redirect to the All Animal Orbs page
    return redirect(url_for('all_orbs'))

#Add Animal Orbs
@app.route('/add_orb', methods=['GET', 'POST'])
def add_orb():
    #Setup Form
    form = Edit_Orb()
    locations = Location.query.all()
    form.locationid.choices = [(location.id, location.name) for location in locations]
    #Name Validation
    form.add.data = True
    #If Submit is clicked set new entries to data columns in db
    if form.validate_on_submit():
        xorb = Orb()
        xorb.name = form.name.data
        xorb.description = form.description.data
        xorb.cost = form.cost.data
        xorb.req = form.req.data
        xorb.locationid = form.locationid.data
        xorb.magicBonus = form.magicBonus.data
        xorb.strengthBonus = form.strengthBonus.data
        xorb.defenseBonus = form.defenseBonus.data
        xorb.agilityBonus = form.agilityBonus.data
        xorb.xpBonus = form.xpBonus.data
        db.session.add(xorb)
        db.session.commit()
        #Redirect to the details page for this Animal Orb
        return redirect(url_for('orb_details', id=xorb.id))
    else:
        #Render the add Animal Orb page
        return render_template('edit_orb.html', form=form, page_title="Adding Animal Orbs")

#Edit Existing Animal Orbs
@app.route('/edit_orb/<id>', methods=['GET', 'POST'])
def edit_orb(id):
    #Setup Form
    form = Edit_Orb()
    locations = Location.query.all()
    orb = Orb.query.get(id)
    form.locationid.choices = [(location.id, location.name) for location in locations]
    #Name Validation bypass
    form.add.data = False
    #Pivot value for validation
    form.id.data = orb.id
    #Intial render, pre populate fields with current database information
    if request.method == 'GET':
        form.name.data = orb.name
        form.locationid.data = orb.locationid
        form.description.data = orb.description
        form.cost.data = orb.cost
        form.req.data = orb.req
        form.magicBonus.data = orb.magicBonus
        form.strengthBonus.data = orb.strengthBonus
        form.defenseBonus.data = orb.defenseBonus
        form.agilityBonus.data = orb.agilityBonus
        form.xpBonus.data = orb.xpBonus
        return render_template('edit_orb.html', form=form, orb=orb, page_title="Editing {}".format(orb.name))
    else:
        #If submitted and validation passes, commit changes
        if form.validate_on_submit():
            xorb = Orb.query.get(id)
            xorb.name = form.name.data
            xorb.locationid = form.locationid.data
            xorb.description = form.description.data
            xorb.cost = form.cost.data
            xorb.req = form.req.data
            xorb.magicBonus = form.magicBonus.data
            xorb.strengthBonus = form.strengthBonus.data
            xorb.defenseBonus = form.defenseBonus.data
            xorb.agilityBonus = form.agilityBonus.data
            xorb.xpBonus = form.xpBonus.data
            db.session.commit()
            return redirect(url_for('orb_details', id=xorb.id))
        else:
            #If validation Fails
            return render_template('edit_orb.html', form=form, orb=orb, page_title="Editing {}".format(orb.name))

#==============================Location Pages==============================#

#All Locations Page, order A-Z
@app.route('/all_locations')
def all_locations():
	locations = Location.query.order_by(Location.name).all()
	return render_template('all_locations.html',page_title="Locations", locations=locations)

#Location Details Page
@app.route('/location/<id>')
def location_details(id):
    location = Location.query.filter_by(id = id).first()
    return render_template('location_details.html', page_title=location.name, location=location)

#Remove Location
@app.route('/remove_location/<id>')
def remove_location(id):
    Location.query.filter_by(id = id).delete()
    db.session.commit()
    return redirect(url_for('all_locations'))

#Add Location Page
@app.route('/add_location', methods=['GET', 'POST'])
def add_location():
    #Setup Form
    form = Edit_Location()
    #Name Validation
    form.add.data = True
    #If the submit button is clicked, validate and add new location
    if form.validate_on_submit():
        xlocation = Location()
        xlocation.name = form.name.data
        xlocation.description = form.description.data
        xlocation.chapter = form.chapter.data
        xlocation.localeType = form.localeType.data
        db.session.add(xlocation)
        db.session.commit()
        return redirect(url_for('location_details', id=xlocation.id))
    else:
        return render_template('edit_location.html', form=form, page_title="Adding Locations")

#Edit Existing Locations
@app.route('/edit_location/<id>', methods=['GET', 'POST'])
def edit_location(id):
    #Setup Form
    form = Edit_Location()
    location = Location.query.get(id)
    #Name Validation bypass
    form.add.data = False
    #Pivot value for validation
    form.id.data = location.id
    #Intial render, pre populate fields with current database information
    if request.method == 'GET':
        form.name.data = location.name
        form.description.data = location.description
        form.chapter.data = location.chapter
        form.localeType.data = location.localeType
        return render_template('edit_location.html', form=form, page_title="Editing {}".format(location.name))
    else:
        #If submitted and validation passes, commit changes
        if form.validate_on_submit():
            xlocation = Location.query.get(id)
            xlocation.name = form.name.data
            xlocation.description = form.description.data
            xlocation.chapter = form.chapter.data
            xlocation.localeType = form.localeType.data
            db.session.commit()
            return redirect(url_for('location_details', id=id))
        else:
            #If validation fails
            return render_template('edit_location.html', form=form, page_title="Editing {}".format(location.name))

#==============================Weapons Pages==============================#

#All Weapons Page, order A-Z
@app.route('/all_weapons')
def all_weapons():
	weapons = Weapon.query.order_by(Weapon.name).all()
	return render_template('all_weapons.html',page_title="Weapons", weapons=weapons)

#Weapon Details Page
@app.route('/weapon/<id>', methods=['GET', 'POST'])
def weapon_details(id):
    weapon = Weapon.query.filter_by(id = id).first()
    location = Location.query.filter_by(id = weapon.locationid).first()
    return render_template('weapon_details.html', page_title=weapon.name, weapon=weapon, location=location)

#Remove Weapon
@app.route('/remove_weapon/<id>')
def remove_weapon(id):
    Weapon.query.filter_by(id = id).delete()
    db.session.commit()
    return redirect(url_for('all_weapons'))

#Add Weapon Page
@app.route('/add_weapon', methods=['GET', 'POST'])
def add_weapon():
    #Setup Form
    form = Edit_Weapon()
    locations = Location.query.all()
    form.locationid.choices = [(location.id, location.name) for location in locations]
    #Name Validation
    form.add.data = True
    #If the submit button is clicked, validate and add weapon
    if form.validate_on_submit():
        xweapon = Weapon()
        xweapon.name = form.name.data
        xweapon.locationid = form.locationid.data
        xweapon.reqItem = form.reqItem.data
        xweapon.reqLevel = form.reqLevel.data
        xweapon.mode = form.mode.data
        xweapon.strength = form.strength.data
        xweapon.magic = form.magic.data
        xweapon.defense = form.defense.data
        xweapon.agility = form.agility.data
        xweapon.iceSpecial = form.iceSpecial.data
        xweapon.critSpecial = form.critSpecial.data
        xweapon.fireSpecial = form.fireSpecial.data
        xweapon.elecSpecial = form.elecSpecial.data
        xweapon.poiSpecial = form.poiSpecial.data
        xweapon.cost = form.cost.data
        db.session.add(xweapon)
        db.session.commit()
        return redirect(url_for('weapon_details', id=xweapon.id))
    else:
        return render_template('edit_weapon.html', form=form, page_title="Adding Weapons")

#Editing Existing Weapon
@app.route('/edit_weapon/<id>', methods=['GET', 'POST'])
def edit_weapon(id):
    #Setup Form
    form = Edit_Weapon()
    weapon = Weapon.query.get(id)
    locations = Location.query.all()
    form.locationid.choices = [(location.id, location.name) for location in locations]
    #Name Validation bypass
    form.add.data = False
    #Pivot value for validation
    form.id.data = weapon.id
    #Intial render, pre populate fields with current database information
    if request.method == 'GET':
        form.name.data = weapon.name
        form.locationid.data = weapon.locationid
        form.reqItem.data = weapon.reqItem
        form.reqLevel.data = weapon.reqLevel
        form.mode.data = weapon.mode
        form.strength.data = weapon.strength
        form.magic.data = weapon.magic
        form.defense.data = weapon.defense
        form.agility.data = weapon.agility
        form.iceSpecial.data = weapon.iceSpecial
        form.critSpecial.data = weapon.critSpecial
        form.fireSpecial.data = weapon.fireSpecial
        form.elecSpecial.data = weapon.elecSpecial
        form.poiSpecial.data = weapon.poiSpecial
        form.cost.data = weapon.cost
        return render_template('edit_weapon.html', form=form, page_title="Editing {}".format(weapon.name))
    else:
        #If submitted and validation passes, commit changes
        if form.validate_on_submit():
            xweapon = Weapon.query.get(id)
            xweapon.name = form.name.data
            xweapon.locationid = form.locationid.data
            xweapon.reqItem = form.reqItem.data
            xweapon.reqLevel = form.reqLevel.data
            xweapon.mode = form.mode.data
            xweapon.strength = form.strength.data
            xweapon.magic = form.magic.data
            xweapon.defense = form.defense.data
            xweapon.agility = form.agility.data
            xweapon.iceSpecial = form.iceSpecial.data
            xweapon.critSpecial = form.critSpecial.data
            xweapon.fireSpecial = form.fireSpecial.data
            xweapon.elecSpecial = form.elecSpecial.data
            xweapon.poiSpecial = form.poiSpecial.data
            xweapon.cost = form.cost.data
            db.session.commit()
            return redirect(url_for('weapon_details', id=xweapon.id))
        else:
        #If validation fails
            return render_template('edit_weapon.html', form=form, page_title="Editing {}".format(weapon.name))


#==============================Error Handlers (Basic)==============================#

#Error Page (General if URL is not found)
@app.errorhandler(404)
def page_not_found(e):
    return render_template('404.html', error=e, page_title="Error 404"), 404

#Internal Errors, unhandled
@app.errorhandler(Exception)
def handle_exception(e):
    #Filter HTTP errors (HTML based)
    if isinstance(e, HTTPException):
        return e
    #Send the user to an internal errors page with the problem
    return render_template("500.html", error=e, page_title="Error 500"), 500
